var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var import_express = __toESM(require("express"), 1);
var import_body_parser = __toESM(require("body-parser"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_bcrypt_nodejs = __toESM(require("bcrypt-nodejs"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config();
const port = process.env.PORT || 8080;
const app = (0, import_express.default)();
const authenticateUser = async (req, res, next) => {
  next();
};
app.use((0, import_cors.default)());
app.use(import_body_parser.default.json());
app.get("/", (req, res) => {
  res.send("Hello Member");
});
app.post("/users", async (req, res) => {
  res.status(201).json({
    success: true,
    message: "User created",
    id: 1,
    accessToken: "mock-access-token"
  });
});
app.post("/sessions", async (req, res) => {
  res.json({ userId: 1, accessToken: "mock-access-token" });
});
app.get("/secrets", authenticateUser);
app.get("/secrets", (req, res) => {
  res.json({ secret: "This is a super secret message" });
});
const startServer = async () => {
  app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
  });
};
startServer();
